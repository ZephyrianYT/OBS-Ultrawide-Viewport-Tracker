-- ============================================================================
-- OBS Ultrawide Viewport Tracker - Master Edition
-- Zero dependencies | Native Lua FFI | Ultra-low CPU | Auto-Detection
-- ============================================================================

local obs = obslua
local ffi = require("ffi")

-- Win32 API & XInput Declarations
ffi.cdef[[
    typedef struct {
        long x;
        long y;
    } POINT;
    int GetCursorPos(POINT* lpPoint);

    typedef struct {
        unsigned short wButtons;
        unsigned char  bLeftTrigger;
        unsigned char  bRightTrigger;
        short          sThumbLX;
        short          sThumbLY;
        short          sThumbRX;
        short          sThumbRY;
    } XINPUT_GAMEPAD;

    typedef struct {
        unsigned long  dwPacketNumber;
        XINPUT_GAMEPAD Gamepad;
    } XINPUT_STATE;

    unsigned long XInputGetState(unsigned long dwUserIndex, XINPUT_STATE* pState);
]]

-- Load XInput dynamically
local xinput = nil
local xinput_dlls = {"xinput1_4.dll", "xinput1_3.dll", "xinput9_1_0.dll"}
for _, dll in ipairs(xinput_dlls) do
    local ok, lib = pcall(ffi.load, dll)
    if ok then
        xinput = lib
        break
    end
end

-- Configuration state
local source_name = ""
local input_device = "mouse"        -- "mouse", "gamepad_rx", "gamepad_lx", "manual"
local aspect_preset = "auto"        -- "auto", "21_9_1440p", "21_9_1080p", "32_9_1440p", "32_9_1080p", "custom"
local tracking_axis = "horizontal"  -- "horizontal", "both"

local source_w = 3440
local source_h = 1440
local target_w = 2560
local target_h = 1440

local smoothness = 12.0
local deadzone_pct = 15.0
local stick_deadzone = 20.0
local idle_return = true
local idle_timeout = 3.0
local monitor_x_offset = 0

-- Runtime tracking variables
local current_x = 0.0
local current_y = 0.0
local target_x = 0.0
local target_y = 0.0
local last_raw_x = 0
local last_raw_y = 0
local idle_timer = 0.0
local is_tracking_enabled = true

-- Preset resolution table
local presets = {
    ["21_9_1440p"] = { sw = 3440, sh = 1440, tw = 2560, th = 1440 },
    ["21_9_1080p"] = { sw = 2560, sh = 1080, tw = 1920, th = 1080 },
    ["32_9_1440p"] = { sw = 5120, sh = 1440, tw = 2560, th = 1440 },
    ["32_9_1080p"] = { sw = 3840, sh = 1080, tw = 1920, th = 1080 },
}

local function clamp(val, min_v, max_v)
    if val < min_v then return min_v end
    if val > max_v then return max_v end
    return val
end

-- Framerate-independent exponential decay easing
local function exp_decay(current, target, speed, dt)
    return target + (current - target) * math.exp(-speed * dt)
end

-- Get Cursor Position (Normalized 0.0 - 1.0)
local function get_mouse_normalized()
    local pt = ffi.new("POINT")
    if ffi.C.GetCursorPos(pt) ~= 0 then
        local px = tonumber(pt.x) - monitor_x_offset
        local py = tonumber(pt.y)
        local nx = clamp(px / source_w, 0.0, 1.0)
        local ny = clamp(py / source_h, 0.0, 1.0)
        return nx, ny, px, py
    end
    return 0.5, 0.5, 0, 0
end

-- Read Active Gamepad Stick (Normalized 0.0 - 1.0)
local function get_gamepad_normalized(use_right_stick)
    if not xinput then return 0.5, 0.5, 0, 0 end

    local state = ffi.new("XINPUT_STATE")
    for pad_idx = 0, 3 do
        if xinput.XInputGetState(pad_idx, state) == 0 then
            local raw_x = use_right_stick and state.Gamepad.sThumbRX or state.Gamepad.sThumbLX
            local raw_y = use_right_stick and state.Gamepad.sThumbRY or state.Gamepad.sThumbLY

            local dz = (stick_deadzone / 100.0) * 32767.0
            local norm_x, norm_y = 0.0, 0.0

            if math.abs(raw_x) > dz then
                norm_x = (raw_x > 0 and (raw_x - dz) or (raw_x + dz)) / (32767.0 - dz)
            end
            if math.abs(raw_y) > dz then
                norm_y = (raw_y > 0 and (raw_y - dz) or (raw_y + dz)) / (32767.0 - dz)
            end

            return clamp((norm_x + 1.0) / 2.0, 0.0, 1.0), clamp((-norm_y + 1.0) / 2.0, 0.0, 1.0), raw_x, raw_y
        end
    end
    return 0.5, 0.5, 0, 0
end

-- Scene Item helper: Finds source across current or target scene
local function get_active_scene_item(scene_source, name)
    if scene_source == nil or name == "" then return nil end
    local scene = obs.obs_scene_from_source(scene_source)
    if scene == nil then return nil end
    return obs.obs_scene_find_source_recursive(scene, name)
end

-- Update Resolution Dimensions
local function update_dimensions()
    if aspect_preset == "auto" then
        local src = obs.obs_get_source_by_name(source_name)
        if src ~= nil then
            local bw = obs.obs_source_get_base_width(src)
            local bh = obs.obs_source_get_base_height(src)
            if bw > 0 and bh > 0 then
                source_w = bw
                source_h = bh
            end
            obs.obs_source_release(src)
        end

        local ovi = obs.obs_video_info()
        if obs.obs_get_video_info(ovi) then
            target_w = ovi.base_width
            target_h = ovi.base_height
        end
    elseif presets[aspect_preset] then
        source_w = presets[aspect_preset].sw
        source_h = presets[aspect_preset].sh
        target_w = presets[aspect_preset].tw
        target_h = presets[aspect_preset].th
    end
end

-- Auto Create / Setup Scene Button Action
local function setup_scene_action()
    if source_name == "" then
        print("[Tracker] Error: Please select a Target Source before setting up scene.")
        return
    end

    update_dimensions()

    local scene_name = "[Tracked] Ultrawide Viewport"
    local scene_src = obs.obs_get_source_by_name(scene_name)
    local scene = nil

    if scene_src == nil then
        scene = obs.obs_scene_create(scene_name)
        scene_src = obs.obs_scene_get_source(scene)
    else
        scene = obs.obs_scene_from_source(scene_src)
    end

    local captured_src = obs.obs_get_source_by_name(source_name)
    if captured_src ~= nil and scene ~= nil then
        local item = obs.obs_scene_find_source(scene, source_name)
        if item == nil then
            item = obs.obs_scene_add(scene, captured_src)
        end

        if item ~= nil then
            local pos = ffi.new("struct vec2")
            pos.x = 0
            pos.y = 0
            obs.obs_sceneitem_set_pos(item, pos)
            obs.obs_sceneitem_set_alignment(item, 0)
        end
        obs.obs_source_release(captured_src)
    end

    if scene_src ~= nil then
        obs.obs_frontend_set_current_scene(scene_src)
        obs.obs_source_release(scene_src)
    end
end

-- Core Frame Loop
function script_tick(seconds)
    if not is_tracking_enabled or source_name == "" then return end

    local max_crop_x = math.max(0, source_w - target_w)
    local max_crop_y = math.max(0, source_h - target_h)

    local norm_x, norm_y, raw_x, raw_y = 0.5, 0.5, 0, 0

    if input_device == "mouse" then
        norm_x, norm_y, raw_x, raw_y = get_mouse_normalized()
    elseif input_device == "gamepad_rx" then
        norm_x, norm_y, raw_x, raw_y = get_gamepad_normalized(true)
    elseif input_device == "gamepad_lx" then
        norm_x, norm_y, raw_x, raw_y = get_gamepad_normalized(false)
    end

    -- Idle Inactivity Detection
    if raw_x ~= last_raw_x or raw_y ~= last_raw_y then
        idle_timer = 0.0
        last_raw_x = raw_x
        last_raw_y = raw_y
    else
        idle_timer = idle_timer + seconds
    end

    if idle_return and idle_timer > idle_timeout and input_device ~= "manual" then
        target_x = max_crop_x / 2.0
        target_y = max_crop_y / 2.0
    elseif input_device ~= "manual" then
        -- Deadzone Processing
        local dz = deadzone_pct / 100.0
        local dx = norm_x - 0.5
        local dy = norm_y - 0.5

        if math.abs(dx) < dz then dx = 0 else
            dx = (dx - (dx > 0 and dz or -dz)) / (1.0 - 2.0 * dz)
        end
        if math.abs(dy) < dz then dy = 0 else
            dy = (dy - (dy > 0 and dz or -dz)) / (1.0 - 2.0 * dz)
        end

        target_x = clamp(dx + 0.5, 0.0, 1.0) * max_crop_x
        if tracking_axis == "both" then
            target_y = clamp(dy + 0.5, 0.0, 1.0) * max_crop_y
        else
            target_y = max_crop_y / 2.0
        end
    end

    -- Smooth Camera Interpolation
    current_x = exp_decay(current_x, target_x, smoothness, seconds)
    current_y = exp_decay(current_y, target_y, smoothness, seconds)

    -- Apply Crop to Source in Current Active Scene
    local current_scene = obs.obs_frontend_get_current_scene()
    if current_scene ~= nil then
        local scene_item = get_active_scene_item(current_scene, source_name)
        if scene_item ~= nil then
            local crop = obs.obs_sceneitem_crop()
            crop.left = math.floor(current_x)
            crop.right = math.floor(max_crop_x - current_x)
            crop.top = math.floor(current_y)
            crop.bottom = math.floor(max_crop_y - current_y)
            obs.obs_sceneitem_set_crop(scene_item, crop)
        end
        obs.obs_source_release(current_scene)
    end
end

-- OBS UI Properties Configuration
function script_properties()
    local props = obs.obs_properties_create()

    -- 1. Setup Button
    obs.obs_properties_add_button(props, "btn_setup", "⚡ 1-Click Auto Setup Scene", function()
        setup_scene_action()
        return true
    end)

    -- 2. Target Source
    local p_source = obs.obs_properties_add_list(props, "source", "Capture Source", obs.OBS_COMBO_TYPE_EDITABLE, obs.OBS_COMBO_FORMAT_STRING)
    local sources = obs.obs_enum_sources()
    if sources ~= nil then
        for _, s in ipairs(sources) do
            local name = obs.obs_source_get_name(s)
            obs.obs_property_list_add_string(p_source, name, name)
        end
        obs.source_list_release(sources)
    end

    -- 3. Input Device Choice
    local p_input = obs.obs_properties_add_list(props, "input_device", "Input Controller", obs.OBS_COMBO_TYPE_LIST, obs.OBS_COMBO_FORMAT_STRING)
    obs.obs_property_list_add_string(p_input, "🖱️ Mouse Cursor Tracking", "mouse")
    obs.obs_property_list_add_string(p_input, "🎮 Controller / Gamepad (Right Stick)", "gamepad_rx")
    obs.obs_property_list_add_string(p_input, "🎮 Controller / Gamepad (Left Stick)", "gamepad_lx")
    obs.obs_property_list_add_string(p_input, "⌨️ Manual Snap / Hotkeys Only", "manual")

    -- 4. Resolution Preset
    local p_preset = obs.obs_properties_add_list(props, "preset", "Resolution & Aspect Ratio", obs.OBS_COMBO_TYPE_LIST, obs.OBS_COMBO_FORMAT_STRING)
    obs.obs_property_list_add_string(p_preset, "✨ Auto-Detect (Source -> 16:9 Canvas)", "auto")
    obs.obs_property_list_add_string(p_preset, "21:9 Ultrawide (3440 x 1440 -> 2560 x 1440)", "21_9_1440p")
    obs.obs_property_list_add_string(p_preset, "21:9 Ultrawide (2560 x 1080 -> 1920 x 1080)", "21_9_1080p")
    obs.obs_property_list_add_string(p_preset, "32:9 Super Ultrawide (5120 x 1440 -> 2560 x 1440)", "32_9_1440p")
    obs.obs_property_list_add_string(p_preset, "32:9 Super Ultrawide (3840 x 1080 -> 1920 x 1080)", "32_9_1080p")
    obs.obs_property_list_add_string(p_preset, "Custom Manual Bounds", "custom")

    -- 5. Tracking Axis
    local p_axis = obs.obs_properties_add_list(props, "tracking_axis", "Tracking Axis", obs.OBS_COMBO_TYPE_LIST, obs.OBS_COMBO_FORMAT_STRING)
    obs.obs_property_list_add_string(p_axis, "Horizontal Only (Left/Right)", "horizontal")
    obs.obs_property_list_add_string(p_axis, "2D (Horizontal & Vertical)", "both")

    -- 6. Tuning Controls
    obs.obs_properties_add_float_slider(props, "smoothness", "Panning Smoothness", 1.0, 30.0, 0.5)
    obs.obs_properties_add_float_slider(props, "deadzone_pct", "Mouse Center Deadzone (%)", 0.0, 40.0, 1.0)
    obs.obs_properties_add_float_slider(props, "stick_deadzone", "Controller Stick Deadzone (%)", 5.0, 50.0, 1.0)
    obs.obs_properties_add_int(props, "monitor_x_offset", "Multi-Monitor X Offset (px)", -7680, 7680, 10)

    obs.obs_properties_add_bool(props, "idle_return", "Auto-Center When Inactive")
    obs.obs_properties_add_float(props, "idle_timeout", "Inactivity Delay (seconds)", 0.5, 10.0, 0.5)

    -- Custom resolution inputs
    obs.obs_properties_add_int(props, "source_w", "Custom Source Width", 640, 7680, 1)
    obs.obs_properties_add_int(props, "source_h", "Custom Source Height", 480, 4320, 1)
    obs.obs_properties_add_int(props, "target_w", "Custom Target Width", 640, 7680, 1)
    obs.obs_properties_add_int(props, "target_h", "Custom Target Height", 480, 4320, 1)

    return props
end

function script_update(settings)
    source_name = obs.obs_data_get_string(settings, "source")
    input_device = obs.obs_data_get_string(settings, "input_device")
    aspect_preset = obs.obs_data_get_string(settings, "preset")
    tracking_axis = obs.obs_data_get_string(settings, "tracking_axis")
    smoothness = obs.obs_data_get_float(settings, "smoothness")
    deadzone_pct = obs.obs_data_get_float(settings, "deadzone_pct")
    stick_deadzone = obs.obs_data_get_float(settings, "stick_deadzone")
    monitor_x_offset = obs.obs_data_get_int(settings, "monitor_x_offset")
    idle_return = obs.obs_data_get_bool(settings, "idle_return")
    idle_timeout = obs.obs_data_get_float(settings, "idle_timeout")

    if aspect_preset == "custom" then
        source_w = obs.obs_data_get_int(settings, "source_w")
        source_h = obs.obs_data_get_int(settings, "source_h")
        target_w = obs.obs_data_get_int(settings, "target_w")
        target_h = obs.obs_data_get_int(settings, "target_h")
    else
        update_dimensions()
    end
end

-- Hotkey Registration
function script_load(settings)
    obs.obs_hotkey_register_frontend("uw_toggle", "Ultrawide: Toggle Tracking", function(pressed)
        if pressed then is_tracking_enabled = not is_tracking_enabled end
    end)
    obs.obs_hotkey_register_frontend("uw_snap_l", "Ultrawide: Snap Viewport Left", function(pressed)
        if pressed then target_x = 0 end
    end)
    obs.obs_hotkey_register_frontend("uw_snap_c", "Ultrawide: Snap Viewport Center", function(pressed)
        if pressed then target_x = math.max(0, source_w - target_w) / 2.0 end
    end)
    obs.obs_hotkey_register_frontend("uw_snap_r", "Ultrawide: Snap Viewport Right", function(pressed)
        if pressed then target_x = math.max(0, source_w - target_w) end
    end)
end

function script_description()
    return "<h2>OBS Ultrawide Viewport Tracker</h2>" ..
           "<p>Dynamic 16:9 viewport panning for 21:9 & 32:9 displays with Mouse & Gamepad support.</p>"
end