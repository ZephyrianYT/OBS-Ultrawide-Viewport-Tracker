# OBS Ultrawide Viewport Tracker

An all-in-one, ultra-lightweight OBS Studio script for Ultrawide (21:9) and Super Ultrawide (32:9) monitors. It dynamically tracks your mouse cursor and smoothly pans a 16:9 viewport across your ultrawide screen so your stream or recording always sees where the action is without black bars or letterboxing.

---

## ✨ Features

- **All-in-One Package:** Supports 21:9 (3440×1440, 2560×1080), 32:9 (5120×1440, 3840×1080), and custom resolutions in a single script.
- **Zero Dependencies:** Pure OBS Lua script using native Win32 API calls. No Python installations, `pip` packages, or runtime configurations required.
- **Framerate-Independent Smoothing:** Uses exponential decay curves to eliminate jitter and micro-stutter at any OBS framerate (30, 60, or 120 FPS).
- **Customizable Deadzones:** Set center tolerance so small cursor movements or menu interactions don't shake the stream camera.
- **Smart Idle Centering:** Automatically glides back to the center of your screen when the cursor is idle.
- **Ultra-Lightweight:** Runs at virtually **0.0% CPU overhead**.

---

## 🚀 Quick Start & Installation

### 1. Download
1. Download `ultrawide_tracker.lua` from the [Releases](https://github.com/ZephyrianYT/OBS-Ultrawide-Viewport-Tracker/releases) tab (or clone the repository).
2. Place the `.lua` file anywhere safe on your PC (e.g., in your OBS scripts folder).

### 2. Add Script to OBS
1. Open **OBS Studio**.
2. Go to **Tools** → **Scripts**.
3. Click the **`+`** (Add) button in the bottom left.
4. Select `ultrawide_tracker.lua`.

### 3. Configure Your Source
1. Select your ultrawide source (Game Capture, Display Capture, or Window Capture) in the **Target Source** dropdown.
2. Select your monitor format under **Display Preset** (or choose *Custom Resolution* to set manual pixel bounds).
3. Adjust the **Camera Smoothness** and **Horizontal Deadzone** to your preference.

---

## ⚙️ Configuration Options

| Setting | Description | Recommended |
|---|---|---|
| **Target Source** | The capture source you want the script to pan and crop. | Your Game / Display Capture |
| **Display Preset** | Pre-configured ratios (21:9 or 32:9) mapping to standard 16:9 viewports. | Match your monitor |
| **Tracking Axis** | `Horizontal Only` tracks left-to-right (best for games with HUDs). `Horizontal & Vertical` enables 2D tracking. | Horizontal Only |
| **Camera Smoothness** | Higher values mean faster, snappier panning; lower values create cinematic, slow gliding. | `10.0 - 15.0` |
| **Horizontal Deadzone** | Percentage of the center screen where cursor motion does not move the viewport. | `10% - 20%` |
| **Auto-Center When Idle**| Returns the viewport to exact center after inactivity. | Enabled (3.0s) |

---

## 💡 Tips for Best Results

- **Canvas Size:** Set your OBS Base (Canvas) Resolution to your target 16:9 output (e.g., `2560x1440` or `1920x1080`).
- **Scaling:** In OBS, make sure your Ultrawide Game Capture / Display Capture transform is set to its native unscaled size so the script can crop the edges cleanly.

---

## 📄 License
MIT License. Feel free to modify and share!